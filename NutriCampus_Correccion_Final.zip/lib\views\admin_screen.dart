import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/estados.dart';
import '../services/firestore_service.dart';
import '../viewmodels/auth_viewmodel.dart';
import '../widgets/pedido_card.dart';

class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final db = context.read<FirestoreService>();
    final auth = context
        .watch<AuthViewModel>(); // Obtenemos el estado de autenticación y rol

    // Protección extra en la UI: Si por alguna razón entra alguien que no es admin
    if (!auth.esAdmin) {
      return Scaffold(
        appBar: AppBar(title: const Text('Acceso Denegado')),
        body: const Center(
          child: Text(
            'No tienes permisos de administrador para ver este panel.',
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Panel de administración')),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: db.todosLosPedidos(),
        builder: (context, snap) {
          if (snap.hasError) {
            return const Center(child: Text('Sin permisos o sin conexión'));
          }
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final pedidos = snap.data!;
          if (pedidos.isEmpty) {
            return const Center(child: Text('No hay pedidos'));
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: pedidos.length,
            separatorBuilder: (_, _) => const SizedBox(height: 10),
            itemBuilder: (_, i) {
              final p = pedidos[i];
              final actual = p['estado'] as String?;

              return PedidoCard(
                pedido: p,
                // El menú desplegable solo se activa si es estrictamente admin
                extra: auth.esAdmin
                    ? DropdownButton<String>(
                        isExpanded: true,
                        value: estadosPedido.contains(actual) ? actual : null,
                        hint: const Text('Cambiar estado'),
                        items: [
                          for (final e in estadosPedido)
                            DropdownMenuItem(
                              value: e,
                              child: Text(etiquetaEstado(e)),
                            ),
                        ],
                        onChanged: (nuevo) {
                          if (nuevo != null) {
                            db.cambiarEstado(p['id'] as String, nuevo);
                          }
                        },
                      )
                    : null, // Si no es admin, no aparece el menú desplegable de modificación
              );
            },
          );
        },
      ),
    );
  }
}
