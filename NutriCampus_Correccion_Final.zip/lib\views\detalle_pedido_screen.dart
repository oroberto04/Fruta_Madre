import '../core/theme.dart';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../core/formato.dart';

const Color _verde = Color(0xFF2E8540);
const Color _verdeOscuro = Color(0xFF1E602E);
const Color _gris = Color(0xFF9CA3AF);
const Color _texto = Color(0xFF1F2937);
const Color _borde = Color(0xFFF0ECE4);

class DetallePedidoScreen extends StatelessWidget {
  final String pedidoId;

  const DetallePedidoScreen({super.key, required this.pedidoId});

  int _pasoActual(String estado) {
    switch (estado.toLowerCase().trim()) {
      case 'pendiente_pago':
      case 'pendiente':
        return 0;
      case 'pagado':
      case 'confirmado':
      case 'recibido':
      case 'aceptado':
        return 1;
      case 'preparacion':
      case 'en_preparacion':
      case 'preparando':
        return 2;
      case 'camino':
      case 'en_camino':
      case 'en_reparto':
      case 'enviado':
        return 3;
      case 'entregado':
      case 'completado':
        return 4;
      default:
        return 0;
    }
  }

  String _nombreEstado(String estado) {
    switch (estado.toLowerCase().trim()) {
      case 'pendiente_pago':
        return 'Pendiente de pago';
      case 'pendiente':
        return 'Pedido pendiente';
      case 'pagado':
      case 'confirmado':
      case 'recibido':
      case 'aceptado':
        return 'Pedido confirmado';
      case 'preparacion':
      case 'en_preparacion':
      case 'preparando':
        return 'En preparación';
      case 'camino':
      case 'en_camino':
      case 'en_reparto':
      case 'enviado':
        return 'En camino';
      case 'entregado':
      case 'completado':
        return 'Pedido entregado';
      case 'cancelado':
        return 'Pedido cancelado';
      default:
        return estado.isEmpty ? 'Pendiente' : estado;
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('pedidos')
          .doc(pedidoId)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Scaffold(
            backgroundColor: AppThemeColors.adaptiveBackground,
            body: Center(child: Text('Error al cargar el pedido')),
          );
        }

        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: AppThemeColors.adaptiveBackground,
            body: Center(child: CircularProgressIndicator(color: _verde)),
          );
        }

        if (!snapshot.data!.exists) {
          return Scaffold(
            backgroundColor: AppThemeColors.adaptiveBackground,
            body: Center(child: Text('El pedido no existe')),
          );
        }

        final pedido = snapshot.data!.data()!;
        final estado = pedido['estado']?.toString() ?? 'pendiente';
        final paso = _pasoActual(estado);
        final cancelado = estado.toLowerCase() == 'cancelado';

        final items = pedido['items'] is List
            ? List<Map<String, dynamic>>.from(
                (pedido['items'] as List).whereType<Map>().map(
                  (item) => Map<String, dynamic>.from(item),
                ),
              )
            : <Map<String, dynamic>>[];

        final total = (pedido['total'] as num?)?.toDouble() ?? 0.0;
        final entrega = pedido['entrega'] is Map
            ? Map<String, dynamic>.from(pedido['entrega'] as Map)
            : <String, dynamic>{};

        return Scaffold(
          backgroundColor: AppThemeColors.adaptiveBackground,
          appBar: AppBar(
            backgroundColor: AppThemeColors.adaptiveBackground,
            foregroundColor: _texto,
            elevation: 0,
            title: Text(
              'Pedido #${pedidoId.length > 8 ? pedidoId.substring(0, 8) : pedidoId}',
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
          body: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppThemeColors.adaptiveSurface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: (AppThemeColors.darkActive
                        ? Colors.white24
                        : _borde),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Seguimiento de tu pedido',
                      style: TextStyle(
                        color: (AppThemeColors.darkActive
                            ? Colors.white
                            : _texto),
                        fontSize: 19,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _nombreEstado(estado),
                      style: const TextStyle(
                        color: _verde,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 24),
                    if (cancelado)
                      const Text(
                        'Este pedido fue cancelado.',
                        style: TextStyle(
                          color: Colors.red,
                          fontWeight: FontWeight.w600,
                        ),
                      )
                    else ...[
                      _PasoSeguimiento(
                        titulo: 'Pedido recibido',
                        hora: 'Tu pedido está registrado',
                        icono: Icons.receipt_long,
                        completado: paso >= 1,
                        activo: paso == 0,
                        ultimo: false,
                      ),
                      _PasoSeguimiento(
                        titulo: 'Pedido confirmado',
                        hora: 'Estamos preparando tu pedido',
                        icono: Icons.check_circle_outline,
                        completado: paso >= 2,
                        activo: paso == 1,
                        ultimo: false,
                      ),
                      _PasoSeguimiento(
                        titulo: 'En preparación',
                        hora: 'Tu comida se está preparando',
                        icono: Icons.restaurant,
                        completado: paso >= 3,
                        activo: paso == 2,
                        ultimo: false,
                      ),
                      _PasoSeguimiento(
                        titulo: 'En camino',
                        hora: 'Tu pedido va hacia su destino',
                        icono: Icons.delivery_dining,
                        completado: paso >= 4,
                        activo: paso == 3,
                        ultimo: false,
                      ),
                      _PasoSeguimiento(
                        titulo: 'Entregado',
                        hora: '¡Que disfrutes tu pedido!',
                        icono: Icons.home_outlined,
                        completado: paso >= 4,
                        activo: paso == 4,
                        ultimo: true,
                      ),
                    ],
                    const SizedBox(height: 10),
                    Text(
                      'El seguimiento se actualiza automáticamente.',
                      style: TextStyle(
                        color: (AppThemeColors.darkActive
                            ? Colors.white70
                            : _gris),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: AppThemeColors.adaptiveSurface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: (AppThemeColors.darkActive
                        ? Colors.white24
                        : _borde),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Resumen del pedido',
                      style: TextStyle(
                        color: (AppThemeColors.darkActive
                            ? Colors.white
                            : _texto),
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 14),
                    if (items.isEmpty)
                      Text(
                        'No hay productos registrados en este pedido.',
                        style: TextStyle(
                          color: (AppThemeColors.darkActive
                              ? Colors.white70
                              : _gris),
                        ),
                      )
                    else
                      ...items.map((item) {
                        final nombre =
                            item['nombre']?.toString() ??
                            item['platilloNombre']?.toString() ??
                            item['platillo']?.toString() ??
                            'Producto';

                        final cantidad =
                            (item['cantidad'] as num?)?.toInt() ?? 1;

                        final precio =
                            (item['precio'] as num?)?.toDouble() ??
                            (item['precioUnitario'] as num?)?.toDouble() ??
                            0.0;

                        final imagen =
                            item['imagen']?.toString() ??
                            item['imagenUrl']?.toString() ??
                            '';

                        final modificadores = item['modificadores'] is List
                            ? (item['modificadores'] as List)
                                  .map((m) => m.toString())
                                  .toList()
                            : <String>[];

                        return Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: _TarjetaProducto(
                            nombre: nombre,
                            cantidad: cantidad,
                            precio: precio,
                            subtotal: precio * cantidad,
                            imagen: imagen,
                            ingredientes: modificadores,
                          ),
                        );
                      }),
                    const Divider(height: 24),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Total',
                          style: TextStyle(
                            color: (AppThemeColors.darkActive
                                ? Colors.white
                                : _texto),
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          moneda(total),
                          style: const TextStyle(
                            color: _verdeOscuro,
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              if (entrega.isNotEmpty) ...[
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: AppThemeColors.adaptiveSurface,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: (AppThemeColors.darkActive
                          ? Colors.white24
                          : _borde),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Datos de entrega',
                        style: TextStyle(
                          color: (AppThemeColors.darkActive
                              ? Colors.white
                              : _texto),
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 12),
                      ...entrega.entries.map(
                        (entry) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Text(
                            '${entry.key}: ${entry.value is Map || entry.value is List ? entry.value.toString() : entry.value ?? ''}',
                            style: TextStyle(
                              color: (AppThemeColors.darkActive
                                  ? Colors.white
                                  : _texto),
                              fontSize: 13,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }
}

class _PasoSeguimiento extends StatelessWidget {
  final String titulo;
  final String hora;
  final IconData icono;
  final bool completado;
  final bool activo;
  final bool ultimo;

  const _PasoSeguimiento({
    required this.titulo,
    required this.hora,
    required this.icono,
    required this.completado,
    required this.activo,
    required this.ultimo,
  });

  @override
  Widget build(BuildContext context) {
    final colorTexto = completado ? _texto : _gris;

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            width: 34,
            child: Column(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: activo
                        ? _verde
                        : completado
                        ? const Color(0xFFE5F4E8)
                        : const Color(0xFFF3F4F6),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: completado
                          ? const Color(0xFF8BC99A)
                          : const Color(0xFFE5E7EB),
                    ),
                    boxShadow: activo
                        ? [
                            BoxShadow(
                              color: _verde.withAlpha(35),
                              blurRadius: 8,
                            ),
                          ]
                        : null,
                  ),
                  child: Icon(
                    icono,
                    size: 17,
                    color: activo
                        ? Colors.white
                        : completado
                        ? _verde
                        : _gris,
                  ),
                ),
                if (!ultimo)
                  Expanded(
                    child: Container(
                      width: 2,
                      margin: const EdgeInsets.symmetric(vertical: 2),
                      color: completado ? _verde : const Color(0xFFE5E7EB),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(top: 2, bottom: ultimo ? 0 : 25),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    titulo,
                    style: TextStyle(
                      color: activo ? _verde : colorTexto,
                      fontSize: 14,
                      fontWeight: activo || completado
                          ? FontWeight.w700
                          : FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    hora,
                    style: TextStyle(
                      color: activo ? _verde : colorTexto,
                      fontSize: 12,
                      fontWeight: activo ? FontWeight.w600 : FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TarjetaProducto extends StatelessWidget {
  final String nombre;
  final int cantidad;
  final double precio;
  final double subtotal;
  final String imagen;
  final List<String> ingredientes;

  const _TarjetaProducto({
    required this.nombre,
    required this.cantidad,
    required this.precio,
    required this.subtotal,
    required this.imagen,
    required this.ingredientes,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppThemeColors.adaptiveSurface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: (AppThemeColors.darkActive ? Colors.white24 : _borde),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x06000000),
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: const Color(0xFFF3F4F6),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE5E7EB)),
            ),
            clipBehavior: Clip.antiAlias,
            child: imagen.isNotEmpty
                ? Image.network(
                    imagen,
                    fit: BoxFit.cover,
                    errorBuilder: (_, _, _) => Icon(
                      Icons.restaurant,
                      color: (AppThemeColors.darkActive
                          ? Colors.white70
                          : _gris),
                      size: 28,
                    ),
                  )
                : Icon(
                    Icons.restaurant,
                    color: (AppThemeColors.darkActive ? Colors.white70 : _gris),
                    size: 28,
                  ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        nombre,
                        style: TextStyle(
                          color: (AppThemeColors.darkActive
                              ? Colors.white
                              : _texto),
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          height: 1.3,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 7,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF9FAFB),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: const Color(0xFFE5E7EB)),
                      ),
                      child: Text(
                        'x$cantidad',
                        style: TextStyle(
                          color: (AppThemeColors.darkActive
                              ? Colors.white70
                              : _gris),
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                Text(
                  moneda(precio),
                  style: TextStyle(
                    color: (AppThemeColors.darkActive ? Colors.white : _texto),
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                if (ingredientes.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  ...ingredientes.map(
                    (ingrediente) => Padding(
                      padding: const EdgeInsets.only(bottom: 3),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(top: 5, right: 6),
                            child: Icon(
                              Icons.circle,
                              size: 4,
                              color: (AppThemeColors.darkActive
                                  ? Colors.white70
                                  : _gris),
                            ),
                          ),
                          Expanded(
                            child: Text(
                              ingrediente,
                              style: TextStyle(
                                color: (AppThemeColors.darkActive
                                    ? Colors.white70
                                    : _gris),
                                fontSize: 11,
                                height: 1.3,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 4),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    'Importe: ${moneda(subtotal)}',
                    style: const TextStyle(
                      color: _verdeOscuro,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
