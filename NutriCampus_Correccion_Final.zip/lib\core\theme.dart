import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const sage = Color(0xFF7FA67A);
  static const forest = Color(0xFF14432A);
  static const cream = Color(0xFFFBF7EF);
  static const wood = Color(0xFFEBCFA6);
  static const woodLight = Color(0xFFF3E2C4);
  static const ink = Color(0xFF2B2B2B);
}

class AppThemeColors {
  // Updated by MaterialApp.builder whenever the selected theme changes.
  static bool darkActive = false;
  static Color get adaptiveText => darkActive ? Colors.white : AppColors.ink;
  static Color get adaptiveMuted =>
      darkActive ? Colors.white70 : const Color(0xFF747E8D);
  static Color get adaptiveSurface =>
      darkActive ? const Color(0xFF202B36) : Colors.white;
  static Color get adaptiveBackground =>
      darkActive ? const Color(0xFF121820) : AppColors.cream;
  static Color get adaptiveBorder =>
      darkActive ? Colors.white24 : const Color(0xFFE8E5E1);
  static Color get adaptiveSoft =>
      darkActive ? const Color(0xFF26333C) : const Color(0xFFF3E2C4);

  static Color icono(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark
      ? Colors.white
      : AppColors.ink;
  static Color textoBlancoOscuro(BuildContext context, Color original) =>
      Theme.of(context).brightness == Brightness.dark ? Colors.white : original;

  static bool esOscuro(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark;

  static Color fondo(BuildContext context) =>
      esOscuro(context) ? const Color(0xFF121820) : AppColors.cream;

  static Color tarjeta(BuildContext context) =>
      esOscuro(context) ? const Color(0xFF202B36) : Colors.white;

  static Color texto(BuildContext context) =>
      esOscuro(context) ? Colors.white : AppColors.ink;

  static Color secundario(BuildContext context) =>
      esOscuro(context) ? Colors.white70 : const Color(0xFF8E877D);

  static Color borde(BuildContext context) =>
      esOscuro(context) ? Colors.white12 : const Color(0xFFEFE9DF);

  static Color superficieSuave(BuildContext context) =>
      esOscuro(context) ? const Color(0xFF26333C) : const Color(0xFFF3E2C4);
}

ThemeData buildTheme({Brightness brightness = Brightness.light}) {
  final oscuro = brightness == Brightness.dark;

  final base = ThemeData(
    useMaterial3: true,
    brightness: brightness,
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.sage,
      brightness: brightness,
    ),
    scaffoldBackgroundColor: oscuro ? const Color(0xFF121820) : AppColors.cream,
    fontFamily: GoogleFonts.poppins().fontFamily,
  );

  return base.copyWith(
    textTheme: base.textTheme.apply(
      bodyColor: oscuro ? Colors.white : AppColors.ink,
      displayColor: oscuro ? Colors.white : AppColors.ink,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: oscuro ? const Color(0xFF1C2830) : AppColors.sage,
      foregroundColor: Colors.white,
      elevation: 0,
      titleTextStyle: GoogleFonts.poppins(
        fontSize: 20,
        fontWeight: FontWeight.w600,
        color: Colors.white,
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.sage,
        foregroundColor: Colors.white,
        minimumSize: const Size.fromHeight(52),
        shape: const StadiumBorder(),
        textStyle: GoogleFonts.poppins(
          fontSize: 16,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: oscuro ? const Color(0xFF26333C) : Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: oscuro ? Colors.white24 : Colors.black12),
      ),
    ),
  );
}
