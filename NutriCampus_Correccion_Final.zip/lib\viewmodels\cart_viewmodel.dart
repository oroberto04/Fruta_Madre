import 'package:flutter/foundation.dart';

import '../models/item_carrito.dart';

class CartViewModel extends ChangeNotifier {
  final List<ItemCarrito> _items = [];

  List<ItemCarrito> get items => List.unmodifiable(_items);
  bool get vacio => _items.isEmpty;
  int get cantidadTotal => _items.fold(0, (s, i) => s + i.cantidad);
  double get total => _items.fold(0.0, (s, i) => s + i.subtotal);

  void agregar(ItemCarrito item) {
    _items.add(item);
    notifyListeners();
  }

  void cambiarCantidad(ItemCarrito item, int delta) {
    item.cantidad += delta;
    if (item.cantidad <= 0) _items.remove(item);
    notifyListeners();
  }

  void limpiar() {
    _items.clear();
    notifyListeners();
  }
}
