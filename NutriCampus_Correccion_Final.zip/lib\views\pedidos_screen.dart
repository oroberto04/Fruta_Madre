import "../core/theme.dart";

import 'package:url_launcher/url_launcher.dart';

import '../services/pago_service.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/firestore_service.dart';
import '../viewmodels/auth_viewmodel.dart';
import 'detalle_pedido_screen.dart';

class PedidosScreen extends StatefulWidget {
  const PedidosScreen({super.key});

  @override
  State<PedidosScreen> createState() => _PedidosScreenState();
}

class _PedidosScreenState extends State<PedidosScreen> {
  final PagoService _pagoService = PagoService();

  String? _pedidoProcesando;

  Future<void> _reintentarPago(String pedidoId) async {
    if (_pedidoProcesando != null) return;

    setState(() {
      _pedidoProcesando = pedidoId;
    });

    try {
      final url = await _pagoService.crearPreferencia(pedidoId);

      final enlace = Uri.tryParse(url);

      if (enlace == null || enlace.scheme != 'https' || enlace.host.isEmpty) {
        throw Exception('El servidor devolvió un enlace inválido.');
      }

      final abierto = await launchUrl(
        enlace,
        mode: LaunchMode.externalApplication,
      );

      if (!abierto) {
        throw Exception('No se pudo abrir el navegador.');
      }

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enlace de pago abierto correctamente.')),
      );
    } catch (e) {
      debugPrint('ERROR REAL DE MERCADO PAGO: $e');

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error al preparar el pago: $e'),
          duration: const Duration(seconds: 10),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _pedidoProcesando = null;
        });
      }
    }
  }

  static const Color _naranja = Color(0xFFD95B16);
  static const Color _oscuro = Color(0xFF142036);
  static const Color _gris = Color(0xFF8E877D);
  static const Color _borde = Color(0xFFEFE9DF);

  int _pestanaSeleccionada = 0;

  bool _esHistorial(String estado) {
    final valor = estado.toLowerCase().trim();

    return valor.contains('entregado') ||
        valor.contains('cancelado') ||
        valor.contains('completado') ||
        valor.contains('finalizado');
  }

  Color _colorEstado(String estado) {
    final valor = estado.toLowerCase().trim();

    if (valor.contains('cancelado')) {
      return const Color(0xFFD83A3A);
    }

    if (valor.contains('entregado') ||
        valor.contains('completado') ||
        valor.contains('finalizado')) {
      return const Color(0xFF249547);
    }

    if (valor.contains('camino') || valor.contains('reparto')) {
      return const Color(0xFF3478C8);
    }

    return _naranja;
  }

  Color _fondoEstado(String estado) {
    final valor = estado.toLowerCase().trim();

    if (valor.contains('cancelado')) {
      return const Color(0xFFFDEEED);
    }

    if (valor.contains('entregado') ||
        valor.contains('completado') ||
        valor.contains('finalizado')) {
      return const Color(0xFFEAF7EE);
    }

    if (valor.contains('camino') || valor.contains('reparto')) {
      return const Color(0xFFEAF2FC);
    }

    return const Color(0xFFFEF4E8);
  }

  String _fechaPedido(Map<String, dynamic> pedido) {
    final valor =
        pedido['fechaCreacion'] ??
        pedido['createdAt'] ??
        pedido['fecha'] ??
        pedido['created_at'];

    if (valor is DateTime) {
      return _formatearFecha(valor);
    }

    if (valor is String) {
      final fecha = DateTime.tryParse(valor);
      if (fecha != null) return _formatearFecha(fecha);
      return valor;
    }

    // Timestamp de Firebase, sin importar directamente su paquete.
    if (valor != null) {
      try {
        final fecha = (valor as dynamic).toDate() as DateTime;
        return _formatearFecha(fecha);
      } catch (_) {
        // Si el campo no es una fecha válida, no mostramos una fecha inventada.
      }
    }

    return 'Fecha no disponible';
  }

  String _formatearFecha(DateTime fecha) {
    const meses = [
      'ene',
      'feb',
      'mar',
      'abr',
      'may',
      'jun',
      'jul',
      'ago',
      'sep',
      'oct',
      'nov',
      'dic',
    ];

    final dia = fecha.day.toString().padLeft(2, '0');
    final mes = meses[fecha.month - 1];
    final hora = fecha.hour.toString().padLeft(2, '0');
    final minuto = fecha.minute.toString().padLeft(2, '0');

    return '$dia $mes ${fecha.year}\n$hora:$minuto';
  }

  String _formatoTotal(dynamic total) {
    double cantidad = 0;

    if (total is num) {
      cantidad = total.toDouble();
    } else if (total is String) {
      cantidad = double.tryParse(total) ?? 0;
    }

    return '\$${cantidad.toStringAsFixed(2)}';
  }

  String _nombrePedido(String pedidoId, int index) {
    if (pedidoId.isEmpty) {
      return 'Pedido ${index + 1}';
    }

    final corto = pedidoId.length > 12 ? pedidoId.substring(0, 12) : pedidoId;

    return '#$corto';
  }

  void _abrirDetalle(BuildContext context, String pedidoId) {
    if (pedidoId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Este pedido no tiene un ID válido.')),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DetallePedidoScreen(pedidoId: pedidoId),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final uid = context.read<AuthViewModel>().uid;
    final db = context.read<FirestoreService>();

    return Scaffold(
      backgroundColor: AppThemeColors.fondo(context),
      appBar: AppBar(
        backgroundColor: AppThemeColors.fondo(context),
        foregroundColor: AppThemeColors.texto(context),
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        title: Text(
          'Mis pedidos',
          style: TextStyle(
            fontSize: 19,
            fontWeight: FontWeight.w700,
            color: AppThemeColors.texto(context),
          ),
        ),
      ),
      body: uid == null
          ? Center(
              child: Text(
                'Inicia sesión para ver tus pedidos',
                style: TextStyle(
                  color: (AppThemeColors.darkActive ? Colors.white70 : _gris),
                ),
              ),
            )
          : StreamBuilder<List<Map<String, dynamic>>>(
              stream: db.pedidosDeUsuario(uid),
              builder: (context, snap) {
                if (snap.hasError) {
                  return Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'No pudimos cargar tus pedidos. Intenta de nuevo.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: (AppThemeColors.darkActive
                              ? Colors.white70
                              : _gris),
                        ),
                      ),
                    ),
                  );
                }

                if (snap.connectionState == ConnectionState.waiting &&
                    !snap.hasData) {
                  return const Center(
                    child: CircularProgressIndicator(color: _naranja),
                  );
                }

                final pedidos = snap.data ?? [];

                final activos = pedidos.where((pedido) {
                  final estado = pedido['estado']?.toString() ?? 'Pendiente';
                  return !_esHistorial(estado);
                }).toList();

                final historial = pedidos.where((pedido) {
                  final estado = pedido['estado']?.toString() ?? 'Pendiente';
                  return _esHistorial(estado);
                }).toList();

                final visibles = _pestanaSeleccionada == 0
                    ? activos
                    : historial;

                return Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFECE7DF),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          children: [
                            _construirPestana(
                              titulo: 'Activos',
                              seleccionada: _pestanaSeleccionada == 0,
                              onTap: () =>
                                  setState(() => _pestanaSeleccionada = 0),
                            ),
                            _construirPestana(
                              titulo: 'Historial',
                              seleccionada: _pestanaSeleccionada == 1,
                              onTap: () =>
                                  setState(() => _pestanaSeleccionada = 1),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Expanded(
                      child: visibles.isEmpty
                          ? _construirVacio()
                          : ListView.separated(
                              padding: const EdgeInsets.fromLTRB(
                                16,
                                12,
                                16,
                                24,
                              ),
                              itemCount: visibles.length,
                              separatorBuilder: (_, _) =>
                                  const SizedBox(height: 14),
                              itemBuilder: (context, index) {
                                final pedido = visibles[index];
                                final pedidoId = pedido['id']?.toString() ?? '';
                                final estado =
                                    pedido['estado']?.toString() ?? 'Pendiente';
                                final total = pedido['total'];

                                return _construirTarjeta(
                                  context: context,
                                  pedido: pedido,
                                  pedidoId: pedidoId,
                                  estado: estado,
                                  total: total,
                                  index: index,
                                );
                              },
                            ),
                    ),
                  ],
                );
              },
            ),
    );
  }

  Widget _construirPestana({
    required String titulo,
    required bool seleccionada,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: Material(
        color: seleccionada ? _naranja : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(
              titulo,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: seleccionada ? Colors.white : const Color(0xFF666056),
                fontSize: 14,
                fontWeight: seleccionada ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _construirVacio() {
    final esHistorial = _pestanaSeleccionada == 1;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 76,
              height: 76,
              decoration: BoxDecoration(
                color: const Color(0xFFF3EFEA),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Icon(
                esHistorial
                    ? Icons.history_rounded
                    : Icons.receipt_long_rounded,
                size: 36,
                color: _naranja,
              ),
            ),
            const SizedBox(height: 18),
            Text(
              esHistorial
                  ? 'Aún no tienes pedidos anteriores'
                  : 'No tienes pedidos activos',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: _oscuro,
                fontSize: 17,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              esHistorial
                  ? 'Aquí aparecerán tus pedidos entregados o cancelados.'
                  : 'Cuando realices un pedido, podrás consultar aquí su estado.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: (AppThemeColors.darkActive ? Colors.white70 : _gris),
                fontSize: 13,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _construirTarjeta({
    required BuildContext context,
    required Map<String, dynamic> pedido,
    required String pedidoId,
    required String estado,
    required dynamic total,
    required int index,
  }) {
    final colorEstado = _colorEstado(estado);
    final fondoEstado = _fondoEstado(estado);

    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => _abrirDetalle(context, pedidoId),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: (AppThemeColors.darkActive ? Colors.white24 : _borde),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(8),
                blurRadius: 12,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _nombrePedido(pedidoId, index),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: _oscuro,
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -0.3,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          _fechaPedido(pedido),
                          style: TextStyle(
                            color: (AppThemeColors.darkActive
                                ? Colors.white70
                                : _gris),
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: fondoEstado,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        estado,
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: colorEstado,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 4),
                  const Icon(
                    Icons.chevron_right_rounded,
                    color: Color(0xFFB5AFA4),
                    size: 21,
                  ),
                ],
              ),
              if ((estado == "pendiente_pago" || estado == "rechazado") &&
                  pedidoId.isNotEmpty) ...[
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    // AQUÍ ESTÁ EL CAMBIO PRINCIPAL:
                    // Deshabilita el botón (lo pone gris) SOLO si el pedido actual
                    // es exactamente el que se está procesando en ese momento.
                    onPressed: _pedidoProcesando == pedidoId
                        ? null
                        : () => _reintentarPago(pedidoId),
                    icon: const Icon(Icons.payment),
                    label: Text(
                      _pedidoProcesando == pedidoId
                          ? "Preparando pago..."
                          : "Reintentar pago",
                    ),
                  ),
                ),
              ],
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Divider(height: 1, color: Color(0xFFF5F2EC)),
              ),
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF0E5),
                      borderRadius: BorderRadius.circular(13),
                    ),
                    child: const Icon(
                      Icons.receipt_long_rounded,
                      color: _naranja,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Ver detalle y seguimiento',
                      style: TextStyle(
                        color: (AppThemeColors.darkActive
                            ? Colors.white70
                            : _gris),
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Text(
                    _formatoTotal(total),
                    style: const TextStyle(
                      color: _oscuro,
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.4,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
