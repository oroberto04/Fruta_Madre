import 'package:url_launcher/url_launcher.dart';

import '../services/pago_service.dart';

import '../core/theme.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/formato.dart';
import '../viewmodels/auth_viewmodel.dart';
import '../viewmodels/cart_viewmodel.dart';
import '../viewmodels/checkout_viewmodel.dart';
import 'direccion_entrega_screen.dart';

const Color _fondo = Color(0xFFFAF7F2);
const Color _naranja = Color(0xFFD3581F);
const Color _azul = Color(0xFF1B2A4A);
const Color _gris = Color(0xFF64748B);
const Color _borde = Color(0xFFF0ECE4);

class PagoScreen extends StatefulWidget {
  final Map<String, dynamic> entrega;

  const PagoScreen({super.key, required this.entrega});

  @override
  State<PagoScreen> createState() => _PagoScreenState();
}

class _PagoScreenState extends State<PagoScreen> {
  late Map<String, dynamic> _entrega;
  String _metodoPago = 'tarjeta';
  bool _confirmando = false;

  @override
  void initState() {
    super.initState();
    _entrega = Map<String, dynamic>.from(widget.entrega);
  }

  Future<void> _cambiarDireccion() async {
    final resultado = await Navigator.of(context).push<Map<String, String>>(
      MaterialPageRoute(builder: (_) => const DireccionEntregaScreen()),
    );

    if (!mounted || resultado == null) return;

    setState(() {
      _entrega = {
        ..._entrega,
        'tipoEntrega': resultado['tipoEntrega'] ?? 'domicilio',
        'direccion': resultado['tipoEntrega'] == 'recoger'
            ? ''
            : [
                resultado['calle'] ?? '',
                resultado['colonia'] ?? '',
                if ((resultado['codigoPostal'] ?? '').isNotEmpty)
                  'C.P. ${resultado['codigoPostal']}',
              ].where((parte) => parte.trim().isNotEmpty).join(', '),
        'referencias': resultado['referencia'] ?? '',
      };
    });
  }

  Future<void> _confirmarPedido() async {
    if (_confirmando) return;

    final auth = context.read<AuthViewModel>();
    final uid = auth.uid;

    if (!auth.logueado || uid == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Inicia sesión para confirmar tu pedido.'),
        ),
      );
      return;
    }

    final cart = context.read<CartViewModel>();
    final vm = context.read<CheckoutViewModel>();
    final messenger = ScaffoldMessenger.of(context);

    if (cart.items.isEmpty) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Tu carrito está vacío.')),
      );
      return;
    }

    if ((_entrega['nombre'] ?? '').toString().trim().isEmpty ||
        (_entrega['telefono'] ?? '').toString().trim().isEmpty) {
      messenger.showSnackBar(
        const SnackBar(
          content: Text('Faltan los datos de quien recibe el pedido.'),
        ),
      );
      return;
    }

    if (_entrega['tipoEntrega'] != 'recoger' &&
        (_entrega['direccion'] ?? '').toString().trim().isEmpty) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Selecciona una dirección de entrega.')),
      );
      return;
    }

    setState(() => _confirmando = true);

    try {
      final pedidoId = await vm.crearPedido(
        uid: uid,
        cart: cart,
        entrega: {..._entrega, 'metodoPago': _metodoPago},
      );

      if (!mounted) return;

      if (pedidoId == null) {
        messenger.showSnackBar(
          SnackBar(content: Text(vm.error ?? 'No se pudo crear el pedido.')),
        );
        return;
      }

      final pagoService = PagoService();
      final urlPago = await pagoService.crearPreferencia(pedidoId);

      final enlace = Uri.tryParse(urlPago);
      if (enlace == null || enlace.scheme != 'https' || enlace.host.isEmpty) {
        throw Exception('Enlace de pago inválido');
      }

      final abierto = await launchUrl(
        enlace,
        mode: LaunchMode.externalApplication,
      );

      if (!mounted) return;

      if (!abierto) {
        throw Exception('No se pudo abrir Mercado Pago');
      }

      messenger.showSnackBar(
        const SnackBar(
          content: Text('Pedido creado. Completa el pago en Mercado Pago.'),
        ),
      );
    } catch (_) {
      if (!mounted) return;

      messenger.showSnackBar(
        const SnackBar(
          content: Text(
            'Ocurrió un error al confirmar el pedido. Intenta de nuevo.',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _confirmando = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartViewModel>();
    final checkout = context.watch<CheckoutViewModel>();
    final procesando = checkout.procesando || _confirmando;
    final recoger = _entrega['tipoEntrega'] == 'recoger';

    final direccion = recoger
        ? 'Recoger en tienda'
        : (_entrega['direccion'] ?? 'Sin dirección seleccionada').toString();

    return Scaffold(
      backgroundColor: AppThemeColors.adaptiveBackground,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                children: [
                  Row(
                    children: [
                      SizedBox(
                        width: 40,
                        height: 44,
                        child: IconButton(
                          onPressed: procesando
                              ? null
                              : () => Navigator.maybePop(context),
                          padding: EdgeInsets.zero,
                          alignment: Alignment.centerLeft,
                          tooltip: 'Volver',
                          icon: const Icon(
                            Icons.arrow_back_ios_new,
                            color: _azul,
                            size: 23,
                          ),
                        ),
                      ),
                      const Expanded(
                        child: Padding(
                          padding: EdgeInsets.only(right: 20),
                          child: Text(
                            'Pago',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: _azul,
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              letterSpacing: -0.4,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 28),
                  const Text(
                    'Resumen del pedido',
                    style: TextStyle(
                      color: _azul,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '${cart.items.fold<int>(0, (suma, item) => suma + item.cantidad)} productos',
                        style: TextStyle(
                          color: (AppThemeColors.darkActive
                              ? Colors.white70
                              : _gris),
                          fontSize: 15,
                        ),
                      ),
                      Text(
                        moneda(cart.total),
                        style: const TextStyle(
                          color: _azul,
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 26),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppThemeColors.adaptiveSurface,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: (AppThemeColors.darkActive
                            ? Colors.white24
                            : _borde),
                      ),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x08000000),
                          blurRadius: 10,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: _fondo,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: const Color(0xFFEAE4D9)),
                          ),
                          child: Icon(
                            recoger
                                ? Icons.storefront_outlined
                                : Icons.location_on_outlined,
                            color: _azul,
                            size: 23,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Dirección de entrega',
                                style: TextStyle(
                                  color: _azul,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                direccion,
                                style: TextStyle(
                                  color: (AppThemeColors.darkActive
                                      ? Colors.white70
                                      : _gris),
                                  fontSize: 13,
                                  height: 1.4,
                                ),
                              ),
                            ],
                          ),
                        ),
                        TextButton(
                          onPressed: procesando ? null : _cambiarDireccion,
                          style: TextButton.styleFrom(
                            foregroundColor: _naranja,
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                          ),
                          child: const Text(
                            'Cambiar',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),
                  const Text(
                    'Método de pago',
                    style: TextStyle(
                      color: _azul,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppThemeColors.adaptiveSurface,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: (AppThemeColors.darkActive
                            ? Colors.white24
                            : _borde),
                      ),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x08000000),
                          blurRadius: 10,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        _MetodoPago(
                          valor: 'tarjeta',
                          seleccionado: _metodoPago,
                          titulo: 'Tarjeta de débito o crédito',
                          icono: Icons.credit_card,
                          colorIcono: const Color(0xFFEEF2F6),
                          colorBorde: const Color(0xFFCBD5E1),
                          onTap: (valor) {
                            setState(() => _metodoPago = valor);
                          },
                        ),
                        _MetodoPago(
                          valor: 'mercadopago',
                          seleccionado: _metodoPago,
                          titulo: 'Mercado Pago',
                          icono: Icons.account_balance_wallet_outlined,
                          colorIcono: const Color(0xFF009EE3),
                          colorBorde: const Color(0xFF009EE3),
                          onTap: (valor) {
                            setState(() => _metodoPago = valor);
                          },
                          iconoBlanco: true,
                        ),
                        _MetodoPago(
                          valor: 'efectivo',
                          seleccionado: _metodoPago,
                          titulo: 'Efectivo al recibir',
                          icono: Icons.payments_outlined,
                          colorIcono: const Color(0xFFEDF7ED),
                          colorBorde: const Color(0xFFC8E6C9),
                          colorSimbolo: const Color(0xFF2E7D32),
                          onTap: (valor) {
                            setState(() => _metodoPago = valor);
                          },
                        ),
                      ],
                    ),
                  ),
                  if (checkout.error != null) ...[
                    const SizedBox(height: 16),
                    Text(
                      checkout.error!,
                      style: const TextStyle(color: Colors.red),
                    ),
                  ],
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
              decoration: const BoxDecoration(color: _fondo),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Total a pagar',
                        style: TextStyle(
                          color: _azul,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        moneda(cart.total),
                        style: const TextStyle(
                          color: _azul,
                          fontSize: 21,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    height: 58,
                    child: ElevatedButton(
                      onPressed: procesando ? null : _confirmarPedido,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _naranja,
                        foregroundColor: Colors.white,
                        disabledBackgroundColor: _naranja.withAlpha(150),
                        elevation: 3,
                        shadowColor: _naranja.withAlpha(65),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(17),
                        ),
                      ),
                      child: procesando
                          ? const SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Text(
                              'Confirmar pedido',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetodoPago extends StatelessWidget {
  final String valor;
  final String seleccionado;
  final String titulo;
  final IconData icono;
  final Color colorIcono;
  final Color colorBorde;
  final Color colorSimbolo;
  final bool iconoBlanco;
  final ValueChanged<String> onTap;

  const _MetodoPago({
    required this.valor,
    required this.seleccionado,
    required this.titulo,
    required this.icono,
    required this.colorIcono,
    required this.colorBorde,
    required this.onTap,
    this.colorSimbolo = _azul,
    this.iconoBlanco = false,
  });

  @override
  Widget build(BuildContext context) {
    final activo = valor == seleccionado;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => onTap(valor),
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 15),
          child: Row(
            children: [
              Icon(
                activo
                    ? Icons.radio_button_checked
                    : Icons.radio_button_unchecked,
                color: activo ? _naranja : const Color(0xFFCBD5E1),
                size: 25,
              ),
              const SizedBox(width: 16),
              Container(
                width: 46,
                height: 38,
                decoration: BoxDecoration(
                  color: colorIcono,
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(color: colorBorde),
                ),
                child: Icon(
                  icono,
                  color: iconoBlanco ? Colors.white : colorSimbolo,
                  size: 23,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  titulo,
                  style: const TextStyle(
                    color: Color(0xFF1A202C),
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
