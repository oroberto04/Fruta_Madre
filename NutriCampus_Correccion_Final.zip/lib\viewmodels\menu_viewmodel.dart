import 'package:flutter/foundation.dart';

import '../models/modificador.dart';
import '../models/platillo.dart';
import '../services/firestore_service.dart';

class MenuViewModel extends ChangeNotifier {
  final FirestoreService _db;

  MenuViewModel(this._db);

  List<Platillo> _platillos = [];
  bool cargando = true;
  String? error;

  List<Platillo> get platillos => _platillos;

  Future<void> cargar() async {
    try {
      _platillos = await _db.obtenerPlatillos();
      error = null;
    } catch (_) {
      error = 'No pudimos cargar el menú. Revisa tu conexión.';
    }
    cargando = false;
    notifyListeners();
  }

  Future<List<Modificador>> modificadoresDe(String platilloId) =>
      _db.obtenerModificadores(platilloId);
}
