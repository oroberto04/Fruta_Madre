import "../core/theme.dart";

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/formato.dart';
import '../viewmodels/cart_viewmodel.dart';
import '../viewmodels/menu_viewmodel.dart';
import 'carrito_screen.dart';
import 'avisos_screen.dart';
import 'pedidos_screen.dart';
import 'perfil_screen.dart';
import 'personalizar_screen.dart';
import 'menu_screen.dart';

class LobbyScreen extends StatefulWidget {
  const LobbyScreen({super.key});

  @override
  State<LobbyScreen> createState() => _LobbyScreenState();
}

class _LobbyScreenState extends State<LobbyScreen> {
  static const Color naranja = Color(0xFFD95C14);
  static const Color verde = Color(0xFF204E35);
  static const Color texto = Color(0xFF1C1917);
  static const Color gris = Color(0xFF78716C);

  static const String logoUrl =
      'https://lh3.googleusercontent.com/aida-public/AB6AXuCjbAgfGqAs-6sgaqbwR0AzAFhuj9ClHm6ujyl7z3UWOXttcpvkL69rlBx3XAPw1yVqowoGpFfA7s7v_tpjpcaNzb2mHf0pDaMONDErGI5ktPBTLpQn81HtToC9i8N9OczsoF8zBZDcfSFt2nqbSf_PM-4G3egRc_JDK5VZ_gGojvhxA97dV9etzXeg72leq17CotkHJOWfvhHQJEVfWeisRs3aZ9NjCopzvqq5-zTgW2pBtrSIcJIrHDb6fpku8VfcvlU';

  static const String bannerUrl =
      'https://lh3.googleusercontent.com/aida-public/AB6AXuBgZ13FxUhh9ZSEY_w3IX4FtZJ2J5xxAynjTbNqU_YGU8SG5Dplxl9_tAC-_u6-mV5IwaFCq0H9oD6Ql-416tX1F5Rj5lhGwsWpvQ-F1ujXFEIdaAjoCVESu2ll7C5LZ6rWA0KmtM9vz3CfkOr4ZI2-XyreIc_W3G4uMPdpkfWNIJ9NRUBI7G-QhdEasiZBvLcDSruRbnX2odfpJPfWNZiYp3rXe8cQTO5Kmx_NgTZFYzdUc1ao0pQR9Q';

  static const List<Map<String, dynamic>> categorias = [
    {'nombre': 'Saludables', 'emoji': '🥗', 'fondo': Color(0xFFE5F3E9)},
    {'nombre': 'Clásicas', 'emoji': '🍲', 'fondo': Color(0xFFFCE8E2)},
    {'nombre': 'Antojitos', 'emoji': '🌮', 'fondo': Color(0xFFFEF4DC)},
    {'nombre': 'Bebidas', 'emoji': '🥤', 'fondo': Color(0xFFE8F3F7)},
  ];

  final TextEditingController _busqueda = TextEditingController();

  String _categoriaSeleccionada = '';
  bool _vistaMenu = false;
  int _indice = 0;

  @override
  void dispose() {
    _busqueda.dispose();
    super.dispose();
  }

  void _abrirPlatillo(BuildContext context, dynamic platillo) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => PersonalizarScreen(platillo: platillo)),
    );
  }

  void _abrirCarrito() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const CarritoScreen()),
    );
  }

  void _seleccionarCategoria(String categoria) {
    setState(() {
      _categoriaSeleccionada = _categoriaSeleccionada == categoria
          ? ''
          : categoria;
      _vistaMenu = true;
      _indice = 1;
    });
  }

  List<dynamic> _filtrarPlatillos(List<dynamic> platillos) {
    var resultado = platillos;

    final busqueda = _busqueda.text.trim().toLowerCase();

    if (busqueda.isNotEmpty) {
      resultado = resultado
          .where((p) => p.nombre.toString().toLowerCase().contains(busqueda))
          .toList();
    }

    if (_categoriaSeleccionada.isNotEmpty) {
      final palabras = switch (_categoriaSeleccionada) {
        'Saludables' => [
          'ensalada',
          'quinoa',
          'saludable',
          'bowl',
          'verdura',
          'wrap',
        ],
        'Clásicas' => ['pollo', 'teriyaki', 'pescado', 'burrito'],
        'Antojitos' => ['taco', 'antojito', 'burrito'],
        'Bebidas' => ['agua', 'jugo', 'bebida', 'limonada', 'té'],
        _ => <String>[],
      };

      resultado = resultado.where((p) {
        final nombre = p.nombre.toString().toLowerCase();
        return palabras.any(nombre.contains);
      }).toList();
    }

    return resultado;
  }

  @override
  Widget build(BuildContext context) {
    final menu = context.watch<MenuViewModel>();
    final carrito = context.watch<CartViewModel>();

    final platillos = _filtrarPlatillos(menu.platillos);

    return Scaffold(
      backgroundColor: AppThemeColors.fondo(context),
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            _encabezado(carrito.cantidadTotal),
            Expanded(
              child: menu.cargando
                  ? const Center(
                      child: CircularProgressIndicator(color: naranja),
                    )
                  : menu.error != null
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.cloud_off_outlined,
                              size: 42,
                              color: (AppThemeColors.darkActive
                                  ? Colors.white70
                                  : gris),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              menu.error!,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: (AppThemeColors.darkActive
                                    ? Colors.white
                                    : texto),
                              ),
                            ),
                            const SizedBox(height: 12),
                            OutlinedButton(
                              onPressed: () => menu.cargar(),
                              child: const Text('Reintentar'),
                            ),
                          ],
                        ),
                      ),
                    )
                  : RefreshIndicator(
                      color: naranja,
                      onRefresh: () => menu.cargar(),
                      child: ListView(
                        padding: const EdgeInsets.fromLTRB(20, 10, 20, 28),
                        children: [
                          if (!_vistaMenu) ...[
                            Text(
                              '¡Hola!',
                              style: TextStyle(
                                fontSize: 32,
                                height: 1.15,
                                fontWeight: FontWeight.w800,
                                letterSpacing: -0.8,
                                color: (AppThemeColors.darkActive
                                    ? Colors.white
                                    : texto),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              '¿Qué se te antoja hoy?',
                              style: TextStyle(
                                color: (AppThemeColors.darkActive
                                    ? Colors.white70
                                    : gris),
                                fontSize: 17,
                              ),
                            ),
                          ] else ...[
                            Text(
                              'Nuestro menú',
                              style: TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.w800,
                                color: (AppThemeColors.darkActive
                                    ? Colors.white
                                    : texto),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Encuentra tu próximo favorito',
                              style: TextStyle(
                                color: (AppThemeColors.darkActive
                                    ? Colors.white70
                                    : gris),
                                fontSize: 15,
                              ),
                            ),
                          ],
                          const SizedBox(height: 20),
                          _buscador(),
                          if (!_vistaMenu) ...[
                            const SizedBox(height: 20),
                            _banner(),
                            const SizedBox(height: 24),
                            _tituloSeccion('Categorías', 'Ver todas', () {
                              setState(() {
                                _vistaMenu = true;
                                _indice = 1;
                                _categoriaSeleccionada = '';
                              });
                            }),
                            const SizedBox(height: 12),
                            _categorias(),
                            const SizedBox(height: 26),
                            _tituloSeccion('Destacados', 'Ver todos', () {
                              setState(() {
                                _vistaMenu = true;
                                _indice = 1;
                                _categoriaSeleccionada = '';
                              });
                            }),
                            const SizedBox(height: 12),
                            if (platillos.isEmpty)
                              _sinResultados()
                            else
                              SizedBox(
                                height: 224,
                                child: ListView.separated(
                                  scrollDirection: Axis.horizontal,
                                  itemCount: platillos.length > 6
                                      ? 6
                                      : platillos.length,
                                  separatorBuilder: (_, _) =>
                                      const SizedBox(width: 12),
                                  itemBuilder: (_, i) =>
                                      _tarjetaDestacada(platillos[i]),
                                ),
                              ),
                          ] else ...[
                            const SizedBox(height: 18),
                            if (_categoriaSeleccionada.isNotEmpty)
                              Align(
                                alignment: Alignment.centerLeft,
                                child: TextButton.icon(
                                  onPressed: () => setState(() {
                                    _categoriaSeleccionada = '';
                                  }),
                                  icon: const Icon(Icons.close, size: 18),
                                  label: Text(
                                    'Quitar filtro: $_categoriaSeleccionada',
                                  ),
                                ),
                              ),
                            if (platillos.isEmpty)
                              _sinResultados()
                            else
                              GridView.builder(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: platillos.length,
                                gridDelegate:
                                    const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 2,
                                      crossAxisSpacing: 12,
                                      mainAxisSpacing: 14,
                                      childAspectRatio: 0.67,
                                    ),
                                itemBuilder: (_, i) =>
                                    _tarjetaMenu(platillos[i]),
                              ),
                          ],
                        ],
                      ),
                    ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _navegacion(),
    );
  }

  Widget _encabezado(int cantidad) {
    return Container(
      color: AppThemeColors.fondo(context),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Image.network(
            logoUrl,
            height: 48,
            width: 110,
            fit: BoxFit.contain,
            errorBuilder: (_, _, _) => const Text(
              'NutriCampus',
              style: TextStyle(
                fontSize: 19,
                color: Color(0xFF245336),
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          Row(
            children: [
              IconButton(
                tooltip: 'Avisos',
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AvisosScreen()),
                ),
                icon: Icon(
                  Icons.notifications_none,
                  color: (AppThemeColors.darkActive ? Colors.white : texto),
                  size: 28,
                ),
              ),
              IconButton(
                tooltip: 'Perfil',
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const PerfilScreen()),
                ),
                icon: Icon(
                  Icons.person_outline,
                  color: (AppThemeColors.darkActive ? Colors.white : texto),
                  size: 29,
                ),
              ),
              const SizedBox(width: 4),
              Stack(
                clipBehavior: Clip.none,
                children: [
                  IconButton(
                    tooltip: 'Carrito',
                    onPressed: _abrirCarrito,
                    icon: Icon(
                      Icons.shopping_cart_outlined,
                      color: (AppThemeColors.darkActive ? Colors.white : texto),
                      size: 28,
                    ),
                  ),
                  if (cantidad > 0)
                    Positioned(
                      top: 1,
                      right: 0,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        constraints: const BoxConstraints(
                          minWidth: 19,
                          minHeight: 19,
                        ),
                        decoration: const BoxDecoration(
                          color: naranja,
                          shape: BoxShape.circle,
                        ),
                        child: Text(
                          cantidad > 99 ? '99+' : '$cantidad',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buscador() {
    return TextField(
      controller: _busqueda,
      onChanged: (_) => setState(() {}),
      onTap: () {
        if (!_vistaMenu) {
          setState(() {
            _vistaMenu = true;
            _indice = 1;
          });
        }
      },
      decoration: InputDecoration(
        hintText: 'Buscar alimentos...',
        hintStyle: TextStyle(
          color: AppThemeColors.darkActive
              ? Colors.white70
              : const Color(0xFFA8A29E),
        ),
        prefixIcon: Icon(
          Icons.search,
          color: AppThemeColors.darkActive
              ? Colors.white70
              : const Color(0xFFA8A29E),
          size: 23,
        ),
        suffixIcon: _busqueda.text.isNotEmpty
            ? IconButton(
                onPressed: () {
                  _busqueda.clear();
                  setState(() {});
                },
                icon: const Icon(Icons.close),
              )
            : null,
        filled: true,
        fillColor: AppThemeColors.darkActive
            ? const Color(0xFF26333C)
            : const Color(0xFFEFECE6),
        contentPadding: const EdgeInsets.symmetric(vertical: 15),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  Widget _banner() {
    return Container(
      height: 160,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: verde,
        borderRadius: BorderRadius.circular(22),
        boxShadow: const [
          BoxShadow(
            color: Color(0x12000000),
            blurRadius: 14,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            right: -12,
            top: 8,
            bottom: 8,
            child: ClipOval(
              child: Image.network(
                bannerUrl,
                width: 164,
                height: 164,
                fit: BoxFit.cover,
                errorBuilder: (_, _, _) => const SizedBox(
                  width: 145,
                  child: Icon(
                    Icons.restaurant,
                    color: Colors.white70,
                    size: 60,
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 17, 140, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Bowls frescos para tu día',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    height: 1.2,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 7),
                const Text(
                  'Nutrición y sabor en cada bocado',
                  style: TextStyle(
                    color: Color(0xFFB8D7C5),
                    fontSize: 11,
                    height: 1.35,
                  ),
                ),
                const Spacer(),
                SizedBox(
                  height: 36,
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _vistaMenu = true;
                        _indice = 1;
                        _categoriaSeleccionada = '';
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: naranja,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text(
                      'Ver menú',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _tituloSeccion(String titulo, String accion, VoidCallback onTap) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          titulo,
          style: TextStyle(
            color: (AppThemeColors.darkActive ? Colors.white : texto),
            fontSize: 19,
            fontWeight: FontWeight.w800,
          ),
        ),
        TextButton(
          onPressed: onTap,
          style: TextButton.styleFrom(
            foregroundColor: naranja,
            padding: EdgeInsets.zero,
            minimumSize: Size.zero,
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
          child: Text(
            accion,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
          ),
        ),
      ],
    );
  }

  Widget _categorias() {
    return Row(
      children: [
        for (int i = 0; i < categorias.length; i++)
          Expanded(
            child: GestureDetector(
              onTap: () =>
                  _seleccionarCategoria(categorias[i]['nombre'] as String),
              child: Column(
                children: [
                  Container(
                    width: 61,
                    height: 61,
                    decoration: BoxDecoration(
                      color: categorias[i]['fondo'] as Color,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: (categorias[i]['fondo'] as Color).withAlpha(180),
                      ),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      categorias[i]['emoji'] as String,
                      style: const TextStyle(fontSize: 27),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    categorias[i]['nombre'] as String,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 11,
                      color: AppThemeColors.darkActive
                          ? Colors.white
                          : const Color(0xFF44403C),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _tarjetaDestacada(dynamic p) {
    return GestureDetector(
      onTap: () => _abrirPlatillo(context, p),
      child: Container(
        width: 154,
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: AppThemeColors.adaptiveSurface,
          borderRadius: BorderRadius.circular(17),
          border: Border.all(color: const Color(0xFFF0EEEB)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x08000000),
              blurRadius: 5,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(11),
                child: SizedBox(
                  width: double.infinity,
                  child: _imagenPlatillo(p.imagen),
                ),
              ),
            ),
            const SizedBox(height: 9),
            Text(
              p.nombre,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: (AppThemeColors.darkActive ? Colors.white : texto),
                fontWeight: FontWeight.w700,
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              moneda(p.precioBase),
              style: TextStyle(
                color: (AppThemeColors.darkActive ? Colors.white70 : gris),
                fontSize: 12,
              ),
            ),
            const SizedBox(height: 5),
            const Row(
              children: [
                Icon(Icons.add_circle_outline, size: 16, color: naranja),
                SizedBox(width: 4),
                Text(
                  'Elegir',
                  style: TextStyle(
                    color: naranja,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _tarjetaMenu(dynamic p) {
    return GestureDetector(
      onTap: () => _abrirPlatillo(context, p),
      child: Container(
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: AppThemeColors.adaptiveSurface,
          borderRadius: BorderRadius.circular(17),
          border: Border.all(color: const Color(0xFFF0EEEB)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  width: double.infinity,
                  child: _imagenPlatillo(p.imagen),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              p.nombre,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: (AppThemeColors.darkActive ? Colors.white : texto),
                fontSize: 13,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              moneda(p.precioBase),
              style: TextStyle(
                color: (AppThemeColors.darkActive ? Colors.white70 : gris),
                fontSize: 12,
              ),
            ),
            const SizedBox(height: 5),
            const Text(
              'Personalizar  →',
              style: TextStyle(
                color: naranja,
                fontSize: 11,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _imagenPlatillo(String ruta) {
    if (ruta.startsWith('http://') || ruta.startsWith('https://')) {
      return Image.network(
        ruta,
        fit: BoxFit.cover,
        errorBuilder: (_, _, _) => _imagenAlternativa(),
      );
    }

    return Image.asset(
      ruta,
      fit: BoxFit.cover,
      errorBuilder: (_, _, _) => _imagenAlternativa(),
    );
  }

  Widget _imagenAlternativa() {
    return Container(
      color: const Color(0xFFEFECE6),
      alignment: Alignment.center,
      child: const Icon(Icons.restaurant, color: Color(0xFF9C948B), size: 38),
    );
  }

  Widget _sinResultados() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 35),
      child: Column(
        children: [
          const Icon(Icons.search_off, size: 45, color: Color(0xFFA8A29E)),
          const SizedBox(height: 10),
          Text(
            'No encontramos platillos con esos criterios.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: (AppThemeColors.darkActive ? Colors.white70 : gris),
            ),
          ),
          TextButton(
            onPressed: () {
              _busqueda.clear();
              setState(() {
                _categoriaSeleccionada = '';
              });
            },
            child: const Text(
              'Mostrar todos',
              style: TextStyle(color: naranja),
            ),
          ),
        ],
      ),
    );
  }

  Widget _navegacion() {
    return NavigationBar(
      height: 70,
      backgroundColor: AppThemeColors.tarjeta(context),
      indicatorColor: Colors.transparent,
      selectedIndex: _indice,
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,

      onDestinationSelected: (i) {
        if (i == 0) {
          setState(() {
            _indice = 0;
            _vistaMenu = false;
            _categoriaSeleccionada = '';
          });
        } else if (i == 1) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const MenuScreen()),
          );
        } else if (i == 2) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const PedidosScreen()),
          );
        } else if (i == 3) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const PerfilScreen()),
          );
        }
      },

      destinations: [
        NavigationDestination(
          icon: Icon(
            Icons.home_outlined,
            color: _indice == 0 ? naranja : const Color(0xFFA8A29E),
          ),
          selectedIcon: const Icon(Icons.home, color: naranja),
          label: 'Inicio',
        ),
        NavigationDestination(
          icon: Icon(
            Icons.menu_book_outlined,
            color: _indice == 1 ? naranja : const Color(0xFFA8A29E),
          ),
          selectedIcon: const Icon(Icons.menu_book, color: naranja),
          label: 'Menú',
        ),
        const NavigationDestination(
          icon: Icon(Icons.assignment_outlined, color: Color(0xFFA8A29E)),
          label: 'Pedidos',
        ),
        const NavigationDestination(
          icon: Icon(Icons.person_outline, color: Color(0xFFA8A29E)),
          label: 'Perfil',
        ),
      ],
    );
  }
}
