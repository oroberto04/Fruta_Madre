import 'platillo.dart';

class ItemCarrito {
  final Platillo platillo;
  final Map<String, List<String>> selecciones; // categoría -> opciones elegidas
  final double precioUnitario;
  int cantidad;

  ItemCarrito({
    required this.platillo,
    required this.selecciones,
    required this.precioUnitario,
    this.cantidad = 1,
  });

  double get subtotal => precioUnitario * cantidad;
  
  String get resumen => selecciones.values.expand((v) => v).join(' · ');

  Map<String, dynamic> toMap() => {
        'platilloId': platillo.id,
        'nombre': platillo.nombre,
        'selecciones': selecciones,
        'precioUnitario': precioUnitario,
        'cantidad': cantidad,
      };
}