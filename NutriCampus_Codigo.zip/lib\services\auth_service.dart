import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final _auth = FirebaseAuth.instance;
  final _db = FirebaseFirestore.instance;

  Stream<User?> get cambios => _auth.authStateChanges();

  Future<void> iniciarSesion(String email, String pass) =>
      _auth.signInWithEmailAndPassword(email: email.trim(), password: pass);

  Future<void> registrar(String email, String pass) async {
    final cred = await _auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: pass,
    );
    
    await _db.collection('usuarios').doc(cred.user!.uid).set({
      'email': email.trim(),
      'rol': 'user',
      'direcciones': [],
      'creado': FieldValue.serverTimestamp(),
    });
  }

  Future<String> rolDe(String uid) async {
    final doc = await _db.collection('usuarios').doc(uid).get();
    return (doc.data()?['rol'] as String?) ?? 'user';
  }

  Future<void> cerrarSesion() => _auth.signOut();
}