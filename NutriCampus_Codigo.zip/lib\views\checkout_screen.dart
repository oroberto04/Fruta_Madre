
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/formato.dart';
import '../viewmodels/auth_viewmodel.dart';
import '../viewmodels/cart_viewmodel.dart';
import 'pago_screen.dart';
import 'direccion_entrega_screen.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _form = GlobalKey<FormState>();
  final _nombre = TextEditingController();
  final _telefono = TextEditingController();
  final _direccion = TextEditingController();
  final _referencias = TextEditingController();

  bool _recogerEnTienda = false;
  bool _procesandoNavegacion = false;

  @override
  void dispose() {
    _nombre.dispose();
    _telefono.dispose();
    _direccion.dispose();
    _referencias.dispose();
    super.dispose();
  }

  String? _requerido(String? valor) {
    if (valor == null || valor.trim().isEmpty) {
      return 'Campo obligatorio';
    }
    return null;
  }

  Future<void> _seleccionarDireccion() async {
    final resultado = await Navigator.of(context)
        .push<Map<String, String>>(
      MaterialPageRoute(
        builder: (_) => const DireccionEntregaScreen(),
      ),
    );

    if (!mounted || resultado == null) return;

    setState(() {
      _recogerEnTienda = resultado['tipoEntrega'] == 'recoger';

      if (_recogerEnTienda) {
        _direccion.clear();
        _referencias.clear();
      } else {
        final calle = resultado['calle'] ?? '';
        final colonia = resultado['colonia'] ?? '';
        final cp = resultado['codigoPostal'] ?? '';

        _direccion.text = [
          calle,
          colonia,
          if (cp.isNotEmpty) 'C.P. $cp',
        ].where((parte) => parte.trim().isNotEmpty).join(', ');

        _referencias.text = resultado['referencia'] ?? '';
      }
    });
  }

  Future<void> _continuarAlPago() async {
    if (_procesandoNavegacion) return;

    final auth = context.read<AuthViewModel>();

    if (!auth.logueado || auth.uid == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Inicia sesión para continuar con tu compra.',
          ),
        ),
      );
      return;
    }

    if (!_form.currentState!.validate()) return;

    final cart = context.read<CartViewModel>();

    if (cart.items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tu carrito está vacío.'),
        ),
      );
      return;
    }

    setState(() => _procesandoNavegacion = true);

    final entrega = <String, dynamic>{
      'nombre': _nombre.text.trim(),
      'telefono': _telefono.text.trim(),
      'tipoEntrega': _recogerEnTienda ? 'recoger' : 'domicilio',
      'direccion': _recogerEnTienda ? '' : _direccion.text.trim(),
      'referencias':
          _recogerEnTienda ? '' : _referencias.text.trim(),
    };

    try {
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => PagoScreen(entrega: entrega),
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _procesandoNavegacion = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartViewModel>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Entrega y pago'),
      ),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'Datos de entrega',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _nombre,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'Nombre de quien recibe',
              ),
              validator: _requerido,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _telefono,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Teléfono',
              ),
              validator: _requerido,
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: _procesandoNavegacion
                  ? null
                  : _seleccionarDireccion,
              icon: const Icon(Icons.location_on_outlined),
              label: const Text('Elegir dirección de entrega'),
            ),
            const SizedBox(height: 12),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(
                  value: false,
                  label: Text('A domicilio'),
                  icon: Icon(Icons.delivery_dining),
                ),
                ButtonSegment(
                  value: true,
                  label: Text('Recoger'),
                  icon: Icon(Icons.storefront_outlined),
                ),
              ],
              selected: {_recogerEnTienda},
              onSelectionChanged: (seleccion) {
                setState(() {
                  _recogerEnTienda = seleccion.first;
                });
              },
            ),
            if (!_recogerEnTienda) ...[
              const SizedBox(height: 12),
              TextFormField(
                controller: _direccion,
                readOnly: true,
                decoration: const InputDecoration(
                  labelText: 'Dirección seleccionada',
                  hintText: 'Elige una dirección arriba',
                ),
                validator: (valor) {
                  if (valor == null || valor.trim().isEmpty) {
                    return 'Selecciona una dirección de entrega';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _referencias,
                decoration: const InputDecoration(
                  labelText: 'Referencias (opcional)',
                ),
              ),
            ],
            const SizedBox(height: 24),
            const Text(
              'Resumen del pedido',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 8),
            for (final item in cart.items)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        '${item.cantidad} x ${item.platillo.nombre}',
                      ),
                    ),
                    Text(moneda(item.subtotal)),
                  ],
                ),
              ),
            const Divider(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Total',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  moneda(cart.total),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            SizedBox(
              height: 52,
              child: ElevatedButton(
                onPressed: _procesandoNavegacion
                    ? null
                    : _continuarAlPago,
                child: _procesandoNavegacion
                    ? const CircularProgressIndicator(
                        color: Colors.white,
                      )
                    : const Text('Continuar al pago'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
