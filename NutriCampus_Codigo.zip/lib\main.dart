import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/theme.dart';
import 'core/tema_controller.dart';
import 'firebase_options.dart';
import 'services/auth_service.dart';
import 'services/firestore_service.dart';
import 'viewmodels/auth_viewmodel.dart';
import 'viewmodels/cart_viewmodel.dart';
import 'viewmodels/checkout_viewmodel.dart';
import 'viewmodels/menu_viewmodel.dart';
import 'views/portada_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<TemaController>(
          create: (_) => TemaController()..cargarTema(),
        ),
        // Servicios base
        Provider<FirestoreService>(create: (_) => FirestoreService()),
        Provider<AuthService>(create: (_) => AuthService()),

        // ViewModels
        ChangeNotifierProvider<MenuViewModel>(
          create: (c) => MenuViewModel(c.read<FirestoreService>())..cargar(),
        ),
        ChangeNotifierProvider<CartViewModel>(create: (_) => CartViewModel()),
        ChangeNotifierProvider<AuthViewModel>(
          create: (c) => AuthViewModel(c.read<AuthService>()),
        ),
        ChangeNotifierProvider<CheckoutViewModel>(
          create: (c) => CheckoutViewModel(c.read<FirestoreService>()),
        ),
      ],
      child: const NutriCampusApp(),
    ),
  );
}

class NutriCampusApp extends StatelessWidget {
  const NutriCampusApp({super.key});

  @override
  Widget build(BuildContext context) {
    final tema = context.watch<TemaController>();

    return MaterialApp(
      title: 'NutriCampus',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      darkTheme: buildTheme(brightness: Brightness.dark),
      themeMode: tema.modo,
      builder: (context, child) => Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 480),
          child: child,
        ),
      ),
      home: const PortadaScreen(),
    );
  }
}
