
import 'package:flutter/material.dart';

const Color _fondo = Color(0xFFFAF7F2);
const Color _naranja = Color(0xFFD95C24);
const Color _oscuro = Color(0xFF1C2430);
const Color _gris = Color(0xFF717D8A);
const Color _borde = Color(0xFFE8E4DE);
const Color _superficie = Colors.white;

class DireccionEntregaScreen extends StatefulWidget {
  const DireccionEntregaScreen({super.key});

  @override
  State<DireccionEntregaScreen> createState() =>
      _DireccionEntregaScreenState();
}

class _DireccionEntregaScreenState extends State<DireccionEntregaScreen> {
  bool _aDomicilio = true;
  String? _direccionSeleccionada = 'casa';
  final _referenciaController = TextEditingController();

  final List<_Direccion> _direcciones = [
    _Direccion(
      id: 'casa',
      nombre: 'Casa',
      calle: 'Av. Universidad 123',
      colonia: 'Col. Centro, Ciudad',
      codigoPostal: '12345',
    ),
    _Direccion(
      id: 'trabajo',
      nombre: 'Trabajo',
      calle: 'Av. Tecnológico 456',
      colonia: 'Col. Campus, Ciudad',
      codigoPostal: '67890',
    ),
  ];

  @override
  void dispose() {
    _referenciaController.dispose();
    super.dispose();
  }

  Future<void> _agregarDireccion() async {
    final nueva = await showDialog<_Direccion>(
      context: context,
      builder: (context) => const _DialogoNuevaDireccion(),
    );

    if (nueva == null || !mounted) return;

    setState(() {
      _direcciones.add(nueva);
      _direccionSeleccionada = nueva.id;
      _aDomicilio = true;
    });
  }

  void _continuar() {
    if (_aDomicilio) {
      if (_direccionSeleccionada == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Selecciona una dirección de entrega.'),
          ),
        );
        return;
      }

      final direccion = _direcciones.firstWhere(
        (d) => d.id == _direccionSeleccionada,
      );

      Navigator.of(context).pop(<String, String>{
        'tipoEntrega': 'domicilio',
        'direccionId': direccion.id,
        'nombreDireccion': direccion.nombre,
        'calle': direccion.calle,
        'colonia': direccion.colonia,
        'codigoPostal': direccion.codigoPostal,
        'referencia': _referenciaController.text.trim(),
      });
    } else {
      Navigator.of(context).pop(<String, String>{
        'tipoEntrega': 'recoger',
        'referencia': '',
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _fondo,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Encabezado.
                    Row(
                      children: [
                        SizedBox(
                          width: 40,
                          height: 44,
                          child: IconButton(
                            onPressed: () => Navigator.maybePop(context),
                            padding: EdgeInsets.zero,
                            alignment: Alignment.centerLeft,
                            tooltip: 'Volver atrás',
                            icon: const Icon(
                              Icons.arrow_back_ios_new,
                              color: _oscuro,
                              size: 23,
                            ),
                          ),
                        ),
                        const Expanded(
                          child: Padding(
                            padding: EdgeInsets.only(right: 20),
                            child: Text(
                              'Dirección y entrega',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: _oscuro,
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                                letterSpacing: -0.4,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 28),

                    // Selector del tipo de entrega.
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEDE9E1),
                        borderRadius: BorderRadius.circular(40),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: _OpcionEntrega(
                              texto: 'A domicilio',
                              activa: _aDomicilio,
                              onTap: () {
                                setState(() => _aDomicilio = true);
                              },
                            ),
                          ),
                          Expanded(
                            child: _OpcionEntrega(
                              texto: 'Recoger en tienda',
                              activa: !_aDomicilio,
                              onTap: () {
                                setState(() => _aDomicilio = false);
                              },
                            ),
                          ),
                        ],
                      ),
                    ),

                    if (_aDomicilio) ...[
                      const SizedBox(height: 32),

                      // Encabezado de direcciones.
                      Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'Mis direcciones',
                              style: TextStyle(
                                color: _oscuro,
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          TextButton(
                            onPressed: _agregarDireccion,
                            style: TextButton.styleFrom(
                              foregroundColor: _naranja,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 4,
                              ),
                              minimumSize: Size.zero,
                              tapTargetSize:
                                  MaterialTapTargetSize.shrinkWrap,
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  'Agregar nueva',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                SizedBox(width: 4),
                                Icon(Icons.add, size: 19),
                              ],
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 14),

                      // Tarjetas de direcciones.
                      ..._direcciones.map((direccion) {
                        final seleccionada =
                            direccion.id == _direccionSeleccionada;

                        return Padding(
                          padding: const EdgeInsets.only(bottom: 14),
                          child: _TarjetaDireccion(
                            direccion: direccion,
                            seleccionada: seleccionada,
                            onTap: () {
                              setState(() {
                                _direccionSeleccionada = direccion.id;
                              });
                            },
                          ),
                        );
                      }),

                      const SizedBox(height: 12),

                      const Text(
                        'Referencia de entrega',
                        style: TextStyle(
                          color: _oscuro,
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                        ),
                      ),

                      const SizedBox(height: 12),

                      TextField(
                        controller: _referenciaController,
                        textCapitalization: TextCapitalization.sentences,
                        decoration: InputDecoration(
                          hintText:
                              'Ej. Casa color blanco, portón negro',
                          hintStyle: const TextStyle(
                            color: Color(0xFF717987),
                            fontSize: 14,
                          ),
                          filled: true,
                          fillColor: _superficie,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 20,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(24),
                            borderSide: const BorderSide(color: _borde),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(24),
                            borderSide: const BorderSide(color: _borde),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(24),
                            borderSide: const BorderSide(
                              color: _naranja,
                              width: 1.5,
                            ),
                          ),
                        ),
                      ),
                    ] else ...[
                      const SizedBox(height: 32),
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: _superficie,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _borde),
                        ),
                        child: const Column(
                          children: [
                            Icon(
                              Icons.storefront_outlined,
                              size: 44,
                              color: _naranja,
                            ),
                            SizedBox(height: 12),
                            Text(
                              'Recoger en tienda',
                              style: TextStyle(
                                color: _oscuro,
                                fontSize: 17,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              'Podrás recoger tu pedido en el punto '
                              'de entrega de NutriCampus.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: _gris,
                                fontSize: 14,
                                height: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),

            // Botón inferior fijo.
            Container(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
              decoration: const BoxDecoration(
                color: _fondo,
              ),
              child: SizedBox(
                width: double.infinity,
                height: 58,
                child: ElevatedButton(
                  onPressed: _continuar,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _naranja,
                    foregroundColor: Colors.white,
                    elevation: 3,
                    shadowColor: _naranja.withAlpha(65),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  child: const Text(
                    'Continuar',
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Direccion {
  final String id;
  final String nombre;
  final String calle;
  final String colonia;
  final String codigoPostal;

  const _Direccion({
    required this.id,
    required this.nombre,
    required this.calle,
    required this.colonia,
    required this.codigoPostal,
  });
}

class _OpcionEntrega extends StatelessWidget {
  final String texto;
  final bool activa;
  final VoidCallback onTap;

  const _OpcionEntrega({
    required this.texto,
    required this.activa,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: activa ? _naranja : Colors.transparent,
      borderRadius: BorderRadius.circular(32),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(32),
        child: Container(
          alignment: Alignment.center,
          padding: const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 14,
          ),
          child: Text(
            texto,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: activa ? Colors.white : _gris,
              fontSize: 13,
              fontWeight: activa ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}

class _TarjetaDireccion extends StatelessWidget {
  final _Direccion direccion;
  final bool seleccionada;
  final VoidCallback onTap;

  const _TarjetaDireccion({
    required this.direccion,
    required this.seleccionada,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _superficie,
      borderRadius: BorderRadius.circular(24),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: seleccionada
                  ? _naranja.withAlpha(75)
                  : const Color(0xFFF0F0F3),
              width: seleccionada ? 2 : 1,
            ),
            boxShadow: const [
              BoxShadow(
                color: Color(0x08000000),
                blurRadius: 10,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(
                Icons.location_on,
                color: seleccionada ? _naranja : const Color(0xFF9CA3AF),
                size: 25,
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      direccion.nombre,
                      style: const TextStyle(
                        color: _oscuro,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 7),
                    Text(
                      '${direccion.calle}\n'
                      '${direccion.colonia}\n'
                      'C.P. ${direccion.codigoPostal}',
                      style: const TextStyle(
                        color: _gris,
                        fontSize: 12,
                        height: 1.65,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(
                seleccionada
                    ? Icons.radio_button_checked
                    : Icons.radio_button_unchecked,
                color: seleccionada
                    ? _naranja
                    : const Color(0xFFD1D5DB),
                size: 25,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DialogoNuevaDireccion extends StatefulWidget {
  const _DialogoNuevaDireccion();

  @override
  State<_DialogoNuevaDireccion> createState() =>
      _DialogoNuevaDireccionState();
}

class _DialogoNuevaDireccionState extends State<_DialogoNuevaDireccion> {
  final _formKey = GlobalKey<FormState>();
  final _nombre = TextEditingController();
  final _calle = TextEditingController();
  final _colonia = TextEditingController();
  final _codigoPostal = TextEditingController();

  @override
  void dispose() {
    _nombre.dispose();
    _calle.dispose();
    _colonia.dispose();
    _codigoPostal.dispose();
    super.dispose();
  }

  void _guardar() {
    if (!_formKey.currentState!.validate()) return;

    final direccion = _Direccion(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      nombre: _nombre.text.trim(),
      calle: _calle.text.trim(),
      colonia: _colonia.text.trim(),
      codigoPostal: _codigoPostal.text.trim(),
    );

    Navigator.of(context).pop(direccion);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: _fondo,
      title: const Text(
        'Agregar dirección',
        style: TextStyle(
          color: _oscuro,
          fontWeight: FontWeight.w700,
        ),
      ),
      content: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _CampoDireccion(
                controller: _nombre,
                etiqueta: 'Nombre',
                pista: 'Casa, trabajo...',
              ),
              const SizedBox(height: 12),
              _CampoDireccion(
                controller: _calle,
                etiqueta: 'Calle y número',
                pista: 'Av. Principal 123',
              ),
              const SizedBox(height: 12),
              _CampoDireccion(
                controller: _colonia,
                etiqueta: 'Colonia y ciudad',
                pista: 'Col. Centro, Ciudad',
              ),
              const SizedBox(height: 12),
              _CampoDireccion(
                controller: _codigoPostal,
                etiqueta: 'Código postal',
                pista: '00000',
                soloNumeros: true,
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text(
            'Cancelar',
            style: TextStyle(color: _gris),
          ),
        ),
        ElevatedButton(
          onPressed: _guardar,
          style: ElevatedButton.styleFrom(
            backgroundColor: _naranja,
            foregroundColor: Colors.white,
          ),
          child: const Text('Guardar'),
        ),
      ],
    );
  }
}

class _CampoDireccion extends StatelessWidget {
  final TextEditingController controller;
  final String etiqueta;
  final String pista;
  final bool soloNumeros;

  const _CampoDireccion({
    required this.controller,
    required this.etiqueta,
    required this.pista,
    this.soloNumeros = false,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      keyboardType:
          soloNumeros ? TextInputType.number : TextInputType.streetAddress,
      maxLength: soloNumeros ? 5 : null,
      decoration: InputDecoration(
        labelText: etiqueta,
        hintText: pista,
        counterText: '',
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _borde),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _naranja),
        ),
      ),
      validator: (valor) {
        if (valor == null || valor.trim().isEmpty) {
          return 'Este campo es obligatorio';
        }

        if (soloNumeros &&
            !RegExp(r'^\d{5}$').hasMatch(valor.trim())) {
          return 'Escribe un código postal de 5 dígitos';
        }

        return null;
      },
    );
  }
}
