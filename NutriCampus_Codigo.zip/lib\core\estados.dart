const estadosPedido = [
  'pendiente_pago',
  'pagado',
  'preparando',
  'listo',
  'entregado',
  'rechazado',
];

String etiquetaEstado(String e) {
  switch (e) {
    case 'pendiente_pago':
      return 'Pendiente de pago';
    case 'pagado':
      return 'Pagado';
    case 'preparando':
      return 'Preparando';
    case 'listo':
      return 'Listo para entregar';
    case 'entregado':
      return 'Entregado';
    case 'rechazado':
      return 'Pago rechazado';
    default:
      return e;
  }
}