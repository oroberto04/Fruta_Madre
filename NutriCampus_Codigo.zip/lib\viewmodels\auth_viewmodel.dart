import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import '../services/auth_service.dart';

class AuthViewModel extends ChangeNotifier {
  final AuthService _auth;
  StreamSubscription? _sub;
  User? _usuario;
  String rol = 'user';
  bool cargando = false;
  String? error;

  AuthViewModel(this._auth) {
    _sub = _auth.cambios.listen((u) async {
      _usuario = u;
      try {
        rol = u == null ? 'user' : await _auth.rolDe(u.uid);
      } catch (_) {
        rol = 'user';
      }
      notifyListeners();
    });
  }

  bool get logueado => _usuario != null;
  bool get esAdmin => rol == 'admin';
  String? get uid => _usuario?.uid;
  String? get email => _usuario?.email;

  Future<bool> entrar(String email, String pass, {required bool crear}) async {
    cargando = true;
    error = null;
    notifyListeners();
    try {
      if (crear) {
        await _auth.registrar(email, pass);
      } else {
        await _auth.iniciarSesion(email, pass);
      }
      return true;
    } on FirebaseAuthException catch (e) {
      error = _mensaje(e.code);
      return false;
    } catch (_) {
      error = 'Algo salió mal. Intenta de nuevo.';
      return false;
    } finally {
      cargando = false;
      notifyListeners();
    }
  }

  Future<void> salir() => _auth.cerrarSesion();

  String _mensaje(String code) {
    switch (code) {
      case 'email-already-in-use':
        return 'Ese correo ya tiene cuenta. Inicia sesión.';
      case 'invalid-email':
        return 'El correo no es válido.';
      case 'weak-password':
        return 'La contraseña debe tener al menos 6 caracteres.';
      case 'invalid-credential':
      case 'user-not-found':
      case 'wrong-password':
        return 'Correo o contraseña incorrectos.';
      case 'network-request-failed':
        return 'Sin conexión a internet.';
      default:
        return 'No se pudo continuar ($code).';
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}