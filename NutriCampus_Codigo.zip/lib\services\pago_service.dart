

import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class PagoService {
  static const String baseUrl =
      'https://nutricampus-pagos-jam.onrender.com';

  Future<Map<String, String>> _headers() async {
    final usuario = FirebaseAuth.instance.currentUser;

    if (usuario == null) {
      throw Exception('Debes iniciar sesión para pagar.');
    }

    final token = await usuario.getIdToken();

    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
  }

  String _mensajeError(http.Response respuesta) {
    String detalle = 'Error del servidor';

    try {
      final datos = jsonDecode(respuesta.body);

      if (datos is Map && datos['error'] is String) {
        detalle = datos['error'];
      }
    } catch (_) {
      detalle = 'El servidor devolvió una respuesta inesperada';
    }

    return 'HTTP ${respuesta.statusCode}: $detalle';
  }

  Future<void> comprobarServidor() async {
    final respuesta = await http
        .get(Uri.parse('$baseUrl/salud'))
        .timeout(const Duration(seconds: 60));

    if (respuesta.statusCode != 200) {
      throw Exception(_mensajeError(respuesta));
    }
  }

  Future<String> crearPreferencia(String pedidoId) async {
    debugPrint('Respuesta de pedido : $pedidoId');
    try {
      final respuesta = await http
          .post(
            Uri.parse('$baseUrl/crear-preferencia'),
            headers: await _headers(),
            body: jsonEncode({'pedidoId': pedidoId}),
          )
          .timeout(const Duration(seconds: 60));

      if (respuesta.statusCode != 200) {
        throw Exception(_mensajeError(respuesta));
      }

      final datos = jsonDecode(respuesta.body);
      final url = datos['url'];

      if (url is! String || url.isEmpty) {
        throw Exception(
          'El servidor no devolvió un enlace de pago.',
        );
      }

      return url;
    } catch (e) {
      debugPrint('ERROR AL CREAR PREFERENCIA: $e');
      rethrow;
    }
  }

  Future<void> verificarPago(String pedidoId) async {
    final respuesta = await http
        .post(
          Uri.parse('$baseUrl/verificar-pago'),
          headers: await _headers(),
          body: jsonEncode({'pedidoId': pedidoId}),
        )
        .timeout(const Duration(seconds: 60));

    if (respuesta.statusCode != 200) {
      throw Exception(_mensajeError(respuesta));
    }
  }
}
