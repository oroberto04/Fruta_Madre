import 'apariencia_screen.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../viewmodels/auth_viewmodel.dart';
import 'login_screen.dart';
import 'pedidos_screen.dart';
import 'admin_screen.dart';

class PerfilScreen extends StatelessWidget {
  Color _colorTarjeta(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark
      ? const Color(0xFF202B36)
      : Colors.white;

  Color _colorTexto(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark ? Colors.white : _oscuro;

  Color _colorSecundario(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark ? Colors.white70 : _gris;

  Color _colorBorde(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark ? Colors.white12 : _borde;

  const PerfilScreen({super.key});

  static const Color _fondo = Color(0xFFFAF7F2);
  static const Color _naranja = Color(0xFFD95B16);
  static const Color _oscuro = Color(0xFF142036);
  static const Color _gris = Color(0xFF8E877D);
  static const Color _borde = Color(0xFFEFE9DF);
  static const Color _rojo = Color(0xFFD83A3A);

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthViewModel>();
    final esOscuro = Theme.of(context).brightness == Brightness.dark;
    final email = auth.email?.trim() ?? '';

    return Scaffold(
      backgroundColor: esOscuro ? const Color(0xFF121820) : _fondo,
      appBar: AppBar(
        backgroundColor: esOscuro ? const Color(0xFF121820) : _fondo,
        foregroundColor: esOscuro ? Colors.white : _oscuro,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        title: Text(
          'Mi perfil',
          style: TextStyle(
            color: _colorTexto(context),
            fontSize: 19,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      body: SafeArea(
        top: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
          children: [
            if (!auth.logueado) ...[
              _construirInvitado(context),
            ] else ...[
              _construirPerfilUsuario(context, email),
              const SizedBox(height: 28),

              _tituloSeccion(context, 'MI CUENTA'),
              const SizedBox(height: 12),

              _construirGrupo(context, [
                _construirOpcion(
                  context: context,

                  icono: Icons.receipt_long_rounded,
                  titulo: 'Mis pedidos',
                  descripcion: 'Consulta tus pedidos y su estado',
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const PedidosScreen()),
                  ),
                ),
                _construirSeparador(context),
                _construirOpcion(
                  context: context,

                  icono: Icons.location_on_outlined,
                  titulo: 'Mis direcciones',
                  descripcion: 'Direcciones de entrega',
                  onTap: () => _mostrarNoDisponible(context),
                ),
                _construirSeparador(context),
                _construirOpcion(
                  context: context,

                  icono: Icons.credit_card_outlined,
                  titulo: 'Métodos de pago',
                  descripcion: 'Opciones de pago disponibles',
                  onTap: () => _mostrarNoDisponible(context),
                ),
              ]),

              const SizedBox(height: 26),
              _tituloSeccion(context, 'PREFERENCIAS'),
              const SizedBox(height: 12),

              _construirGrupo(context, [
                _construirOpcion(
                  context: context,

                  icono: Icons.notifications_none_rounded,
                  titulo: 'Notificaciones',
                  descripcion: 'Avisos sobre tus pedidos',
                  onTap: () => _mostrarNoDisponible(context),
                ),
                _construirSeparador(context),
                _construirOpcion(
                  context: context,

                  icono: Icons.palette_outlined,
                  titulo: 'Apariencia',
                  descripcion: 'Personaliza la apariencia de la app',
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AparienciaScreen()),
                  ),
                ),
              ]),

              const SizedBox(height: 26),
              _tituloSeccion(context, 'AYUDA'),
              const SizedBox(height: 12),

              _construirGrupo(context, [
                _construirOpcion(
                  context: context,

                  icono: Icons.help_outline_rounded,
                  titulo: 'Ayuda y contacto',
                  descripcion: 'Obtén asistencia',
                  onTap: () => _mostrarNoDisponible(context),
                ),
              ]),

              const SizedBox(height: 26),
              _tituloSeccion(context, 'ADMINISTRACIÓN'),
              const SizedBox(height: 12),

              _construirGrupo(context, [
                _construirOpcion(
                  context: context,

                  icono: Icons.admin_panel_settings_outlined,
                  titulo: 'Panel de administración',
                  descripcion: 'Administrar NutriCampus',
                  colorIcono: _naranja,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AdminScreen()),
                  ),
                ),
              ]),

              const SizedBox(height: 26),

              OutlinedButton.icon(
                onPressed: () => _confirmarCerrarSesion(context, auth),
                icon: const Icon(Icons.logout_rounded, size: 20),
                label: Text('Cerrar sesión'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: _rojo,
                  side: const BorderSide(color: Color(0xFFF1D7D4)),
                  backgroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 52),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  textStyle: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),

              const SizedBox(height: 20),
              Center(
                child: Text(
                  'NutriCampus',
                  style: TextStyle(
                    color: _colorSecundario(context),
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _construirPerfilUsuario(BuildContext context, String email) {
    final inicial = email.isNotEmpty
        ? email.substring(0, 1).toUpperCase()
        : 'U';

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _colorTarjeta(context),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _colorBorde(context)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(8),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 66,
            height: 66,
            decoration: BoxDecoration(
              color: const Color(0xFFFFEBDD),
              borderRadius: BorderRadius.circular(22),
            ),
            alignment: Alignment.center,
            child: Text(
              inicial,
              style: TextStyle(
                color: _naranja,
                fontSize: 28,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '¡Hola!',
                  style: TextStyle(
                    color: _colorSecundario(context),
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  'Mi cuenta',
                  style: TextStyle(
                    color: _colorTexto(context),
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  email.isEmpty ? 'Sesión iniciada' : email,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: _colorSecundario(context),
                    fontSize: 12,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 6),
          const Icon(
            Icons.verified_user_outlined,
            color: Color(0xFF249547),
            size: 23,
          ),
        ],
      ),
    );
  }

  Widget _construirInvitado(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: _colorTarjeta(context),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _colorBorde(context)),
      ),
      child: Column(
        children: [
          Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              color: const Color(0xFFFFEBDD),
              borderRadius: BorderRadius.circular(25),
            ),
            child: const Icon(
              Icons.person_outline_rounded,
              size: 40,
              color: _naranja,
            ),
          ),
          const SizedBox(height: 18),
          Text(
            'Tu perfil te espera',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _colorTexto(context),
              fontSize: 20,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Inicia sesión para consultar tus pedidos y acceder a tu cuenta.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _colorSecundario(context),
              fontSize: 13,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 22),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const LoginScreen()),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: _naranja,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: Text(
                'Iniciar sesión o crear cuenta',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tituloSeccion(BuildContext context, String texto) {
    return Text(
      texto,
      style: TextStyle(
        color: _colorSecundario(context),
        fontSize: 11,
        fontWeight: FontWeight.w800,
        letterSpacing: 1.3,
      ),
    );
  }

  Widget _construirGrupo(BuildContext context, List<Widget> opciones) {
    return Container(
      decoration: BoxDecoration(
        color: _colorTarjeta(context),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _colorBorde(context)),
      ),
      child: Column(children: opciones),
    );
  }

  Widget _construirSeparador(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.only(left: 58),
      child: Divider(height: 1, thickness: 1, color: Color(0xFFF4F0E9)),
    );
  }

  Widget _construirOpcion({
    required BuildContext context,
    required IconData icono,
    required String titulo,
    required String descripcion,
    required VoidCallback onTap,
    Color colorIcono = _naranja,
  }) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: colorIcono == _rojo
                      ? const Color(0xFFFDEEED)
                      : const Color(0xFFFFF0E5),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(icono, color: colorIcono, size: 22),
              ),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      titulo,
                      style: TextStyle(
                        color: _colorTexto(context),
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      descripcion,
                      style: TextStyle(
                        color: _colorSecundario(context),
                        fontSize: 11,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Icon(
                Icons.chevron_right_rounded,
                color: Color(0xFFB5AFA4),
                size: 22,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _mostrarNoDisponible(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Esta opción estará disponible cuando integremos su funcionalidad.',
        ),
      ),
    );
  }

  Future<void> _confirmarCerrarSesion(
    BuildContext context,
    AuthViewModel auth,
  ) async {
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: Colors.white,
        title: Text(
          'Cerrar sesión',
          style: TextStyle(
            color: _colorTexto(context),
            fontWeight: FontWeight.w700,
          ),
        ),
        content: Text(
          '¿Seguro que deseas cerrar tu sesión?',
          style: TextStyle(color: _gris),
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: Text('Cancelar', style: TextStyle(color: _gris)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(
              'Cerrar sesión',
              style: TextStyle(color: _rojo, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );

    if (confirmar == true && context.mounted) {
      await auth.salir();
    }
  }
}
